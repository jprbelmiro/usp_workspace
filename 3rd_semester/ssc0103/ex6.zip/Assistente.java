package poo.empresa;

public class Assistente extends Funcionario{
	
	@Override
	public double calculaSalario() {
		double salarioReal = salarioBase * 1;
		return salarioReal;
	}

	public Assistente(String nome, String CPF, double salarioBase){
		super(nome,CPF,salarioBase);
	}
	
	public Assistente(){
		super(null,null,0);
	}
	
}
