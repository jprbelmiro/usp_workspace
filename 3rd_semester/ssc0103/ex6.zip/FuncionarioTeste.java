package poo.empresa;

import java.util.ArrayList;

import poo.EntradaTeclado;

/**
* Esta classe foi criada visando realizar testes em cima da criacacao de
* funcionarios de uma empresa/orgao.
* Basicamente a classe possui um metodo main que deixa o usuario realizar
* a entrada pelo teclado do nome, CPF e salario base do funcionario que se
* cria, realizando sempre uma verificacao se a entrada e valida e exibindo
* ao final a folha salarial dos funcionarios criados.
* O metodo main exibira uma interface, mas sempre ira pedir para se entrar
* dados primeiramente de um gerente, depois um assistente e por ultimo de
* um vendedor.
* O programa e encerrado quando o usario selecionar a opcao de sair antes
* de comecao a insercao.
* 
* @author miçanga
*/
public class FuncionarioTeste {

	private static final String BOAS_VINDAS = "|\tTESTE FUNCIONARIOS\n"
											+ "| Bem vindo ao programa criado para testar as classes relacionadas aos Funcionarios.\n";
	
	/**
	* Essa função é responsavel por realizar o teste das classes relacionadas
	* a classe base Funcionario.
	* @return vazio
	*/
	public static void main(String[] args) {
		System.out.println(BOAS_VINDAS);
		ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
		
		Gerente g = null;
		Assistente a = null;
		Vendedor v = null;
		
		int continuar = 1;
		double somaSalarial = 0;
		
		while(continuar != 0){
			String nome = null;
			String CPF = null;
			double salarioBase = 0;
			double comissao = 0;
			
			System.out.printf("| Voce deseja realizar insercao de funcionarios?\n| Caso deseje sair, digite 0.\n");
			try{continuar = EntradaTeclado.leInt();}catch(Exception e){}
			
			if(continuar != 0){
				//Criando os funcionarios
				//1. Gerente
				System.out.printf(":: GERENTE ::\n");
				System.out.printf("nome: ");
				try{nome = EntradaTeclado.leString();}catch(Exception e){}
				System.out.printf("cpf: ");
				try{CPF = EntradaTeclado.leString();}catch(Exception e){}
				System.out.printf("salario base: ");
				try{salarioBase = EntradaTeclado.leDouble();}catch(Exception e){}
				if(Funcionario.verificaCPF(CPF)){
					g = new Gerente(nome,CPF,salarioBase);
					funcionarios.add(g);
				}
				
				//2. Assistente
				System.out.printf("\n:: ASSISTENTE ::\n");
				System.out.printf("nome: ");
				try{nome = EntradaTeclado.leString();}catch(Exception e){}
				System.out.printf("cpf: ");
				try{CPF = EntradaTeclado.leString();}catch(Exception e){}
				System.out.printf("salario base: ");
				try{salarioBase = EntradaTeclado.leDouble();}catch(Exception e){}
				if(Funcionario.verificaCPF(CPF)){
					a = new Assistente(nome,CPF,salarioBase);
					funcionarios.add(a);
				}
				
				//3. Vendedor
				System.out.printf("\n:: VENDEDOR ::\n");
				System.out.printf("nome: ");
				try{nome = EntradaTeclado.leString();}catch(Exception e){}
				System.out.printf("cpf: ");
				try{CPF = EntradaTeclado.leString();}catch(Exception e){}
				System.out.printf("salario base: ");
				try{salarioBase = EntradaTeclado.leDouble();}catch(Exception e){}
				System.out.printf("comissao: ");
				try{comissao = EntradaTeclado.leDouble();}catch(Exception e){}
				if(Funcionario.verificaCPF(CPF)){
					v = new Vendedor(nome,CPF,salarioBase,comissao);
					funcionarios.add(v);
				}
			}
			
			//Imprimindo a folha salarial...
			System.out.println();
			somaSalarial = 0;
			for(int i = 0 ; i < funcionarios.size() ; i++){
				somaSalarial += funcionarios.get(i).calculaSalario();
			}
			System.out.printf("|folha salarial da empresa: %f\n\n",somaSalarial);
		}
	}

}
