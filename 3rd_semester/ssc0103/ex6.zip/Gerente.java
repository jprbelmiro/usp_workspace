package poo.empresa;

public class Gerente extends Funcionario{

	@Override
	public double calculaSalario() {
		double salarioReal = salarioBase * 2;
		return salarioReal;
	}

	public Gerente(String nome, String CPF, double salarioBase){
		super(nome,CPF,salarioBase);
	}
	
	public Gerente(){
		super(null,null,0);
	}
	
}
