package poo.empresa;

public class Vendedor extends Funcionario{
	
	private double comissao;
	
	@Override
	public double calculaSalario() {
		double salarioReal = salarioBase + comissao ;
		return salarioReal;
	}
	

	public double getComissao() {
		return comissao;
	}

	public void setComissao(double comissao) {
		this.comissao = comissao;
	}
	
	public Vendedor(String nome, String CPF, double salarioBase, double comissao){
		super(nome,CPF,salarioBase);
		this.comissao = comissao;
	}
	
	public Vendedor(double comissao){
		super(null,null,0);
		this.comissao = comissao;
	}
			
	
	public Vendedor(){
		super(null,null,0);
		setComissao(0);
	}

}
