package poo.empresa;

public abstract class Funcionario {
		
	protected String nome;
	protected String CPF;
	protected double salarioBase;
	
	public static boolean verificaCPF(String CPF) {
		//1. Calculando o primeiro digito...
		//a) Criando o vetor de pesos da verificacao...
		int[] vetor = new int[9];
		for(int i = 0 ; i < 9 ; i++)
			vetor[i] = 10 - i;
		
		//b) Multiplicando cada posicao da coluna com o digito do
		//cpf correspondente...
		for(int i = 0 ; i < 9 ; i++)
			vetor[i] *= (CPF.charAt(i) - '0');
		
		//c) Calculando o somatorio dos numeros gerados...
		int somatorio = 0;
		for(int i = 0 ; i < 9 ; i++)
			somatorio += vetor[i];
		
		//d) Calculando o primeiro digito e verificando-o...
		//- caso o primeiro digito seja invalido, retorna-se que o cpf 
		//e invalido...
		char primeiroDigito = '0';
		if(11 - (somatorio % 11) <= 9)
			primeiroDigito = (char)(11 - (somatorio % 11) + '0');
		
		if(primeiroDigito != CPF.charAt(11)) return false;
		
		//2. Calculando o segundo digito...
		//a) Criando o vetor de pesos da verificacao...
		vetor = new int[10];
		for(int i = 0 ; i < 10 ; i++)
			vetor[i] = 11 - i;
		
		//b) Multiplicando cada posicao da coluna com o digito do
		//cpf correspondente...
		for(int i = 0 ; i < 10 ; i++)
			vetor[i] *= (CPF.charAt(i) - '0');
		
		//c) Calculando o somatorio dos numeros gerados...
		somatorio = 0;
		for(int i = 0 ; i < 9 ; i++)
			somatorio += vetor[i];
		
		//d) Calculando o primeiro digito e verificando-o...
		//- caso o primeiro digito seja invalido, retorna-se que o cpf 
		//e invalido...
		char segundoDigito = '0';
		if(11 - (somatorio % 11) <= 9)
			segundoDigito = (char)(11 - (somatorio % 11) + '0');
		
		if(segundoDigito != CPF.charAt(12)) return false;
		
		return true;
	}
	
	public abstract double calculaSalario();
	
	public String getNome(){
		return nome;
	}
	
	public void setNome(String nome){
		this.nome = nome;
	}
	
	public String getCPF(){
		return CPF;
	}
	
	public void setCPF(String CPF){
		this.CPF = CPF;
	}
	
	public double getSalarioBase(){
		return salarioBase;
	}
	
	public void setSalarioBase(double salarioBase){
		this.salarioBase = salarioBase;
	}
	
	public Funcionario(String nome, String CPF, double salarioBase){
		this.nome = null;
		this.CPF = null;
		this.salarioBase = 0;
	}
	
	public Funcionario(){
		nome = null;
		CPF = null;
		salarioBase = 0;
	}
	
}
