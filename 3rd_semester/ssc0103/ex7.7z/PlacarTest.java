package poo.bozo;

import static org.junit.Assert.*;

import org.junit.Test;

public class PlacarTest {

	@Test
	public void testPlacar() {
		Placar pl = new Placar();
		assertEquals(-1,pl.getPosicoes()[0]);
		assertEquals(-1,pl.getPosicoes()[1]);
		assertEquals(-1,pl.getPosicoes()[2]);
		assertEquals(-1,pl.getPosicoes()[3]);
		assertEquals(-1,pl.getPosicoes()[4]);
		assertEquals(-1,pl.getPosicoes()[5]);
		assertEquals(-1,pl.getPosicoes()[6]);
		assertEquals(-1,pl.getPosicoes()[7]);
		assertEquals(-1,pl.getPosicoes()[8]);
		assertEquals(-1,pl.getPosicoes()[9]);
	}

	@Test
	public void testAdd() {
		Placar pl = new Placar();
		int[] dados = new int[5];
		dados[0] = 2;
		dados[1] = 2;
		dados[2] = 2;
		dados[3] = 2;
		dados[4] = 2;
		pl.add(2, dados);
		
		dados[0] = 2;
		dados[1] = 4;
		dados[2] = 4;
		dados[3] = 5;
		dados[4] = 1;
		pl.add(1, dados);
		
		pl.add(10,new int[]{1,2,3,4,5});
		
	}

	@Test
	public void testGetScore() {
		Placar pl = new Placar();
		int[] dados = new int[5];
		dados[0] = 2;
		dados[1] = 2;
		dados[2] = 2;
		dados[3] = 2;
		dados[4] = 2;
		pl.add(2, dados);

		dados[0] = 5;
		dados[1] = 5;
		dados[2] = 5;
		dados[3] = 5;
		dados[4] = 5;
		pl.add(5, dados);
		
		assertEquals(35,pl.getScore());
		
		dados[0] = 1;
		dados[1] = 1;
		dados[2] = 2;
		dados[3] = 3;
		dados[4] = 4;
		pl.add(1, dados);
		
		assertEquals(37,pl.getScore());
	}

	@Test
	public void testGetPosicoes( ){
		Placar pl = new Placar();
		int[] posicoes = new int[10];
		for(int i = 0; i < 10; i++)
			posicoes[i] = -1;
		assertEquals(posicoes[0],pl.getPosicoes()[0]);
		assertEquals(posicoes[1],pl.getPosicoes()[1]);
		assertEquals(posicoes[2],pl.getPosicoes()[2]);
		assertEquals(posicoes[3],pl.getPosicoes()[3]);
		assertEquals(posicoes[4],pl.getPosicoes()[4]);
		assertEquals(posicoes[5],pl.getPosicoes()[5]);
		assertEquals(posicoes[6],pl.getPosicoes()[6]);
		assertEquals(posicoes[7],pl.getPosicoes()[7]);
		assertEquals(posicoes[8],pl.getPosicoes()[8]);
		assertEquals(posicoes[9],pl.getPosicoes()[9]);
	}
	
	@Test
	public void testToString() {
		Placar pl = new Placar();
		
		String s = new String();
		s = "(1)";
		s += "    |   ";
		s += "(7)";
		s += "    |   ";
		s += "(4)";
		s += " \n--------------------------\n";
		s += "(2)";
		s += "    |   ";
		s += "(8)";
		s += "    |   ";
		s += "(5)";
		s += " \n--------------------------\n";
		s += "(3)";
		s += "    |   ";
		s += "(9)";
		s += "    |   ";
		s += "(6)";
		s += " \n--------------------------\n       |   ";
		s +="(10)";
		s +="   |\n       +----------+\n";
		assertEquals(s,pl.toString());
		
		pl.add(1,new int[]{1,2,3,4,5});
		pl.add(2,new int[]{1,2,3,4,5});
		pl.add(3,new int[]{1,2,3,4,5});
		pl.add(4,new int[]{1,2,3,4,5});
		pl.add(5,new int[]{1,2,3,4,5});
		pl.add(6,new int[]{2,3,3,4,6});
		
		s = " 1 ";
		s += "    |   ";
		s += "(7)";
		s += "    |   ";
		s += " 4 ";
		s += " \n--------------------------\n";
		s += " 2 ";
		s += "    |   ";
		s += "(8)";
		s += "    |   ";
		s += " 5 ";
		s += " \n--------------------------\n";
		s += " 3 ";
		s += "    |   ";
		s += "(9)";
		s += "    |   ";
		s += " 6 ";
		s += " \n--------------------------\n       |   ";
		s +="(10)";
		s +="   |\n       +----------+\n";
		assertEquals(s,pl.toString());
		
		pl.add(7,new int[]{1,1,1,3,3});
		pl.add(8,new int[]{5,4,3,2,1});
		pl.add(9,new int[]{1,1,1,1,5});
		pl.add(10,new int[]{1,1,1,1,1});
		pl.add(11,new int[]{1,2,3,4,5});
		
		s = " 1 ";
		s += "    |   ";
		s += "15 ";
		s += "    |   ";
		s += " 4 ";
		s += " \n--------------------------\n";
		s += " 2 ";
		s += "    |   ";
		s += "20 ";
		s += "    |   ";
		s += " 5 ";
		s += " \n--------------------------\n";
		s += " 3 ";
		s += "    |   ";
		s += "30 ";
		s += "    |   ";
		s += " 6 ";
		s +=  " \n--------------------------\n       |   ";
		s += " "+40+" ";
		s +="   |\n       +----------+\n";
		assertEquals(s,pl.toString());
		
		pl.add(1,new int[]{1,1,1,1,1});
		pl.add(2,new int[]{2,2,2,2,2});
		pl.add(3,new int[]{3,3,3,3,3});
		pl.add(4,new int[]{4,4,4,4,4});
		pl.add(5,new int[]{5,5,5,5,5});
		pl.add(6,new int[]{6,6,6,6,6});
		pl.add(7,new int[]{1,2,3,4,5});
		pl.add(8,new int[]{1,1,1,1,1});
		pl.add(9,new int[]{1,4,4,3,5});
		pl.add(10,new int[]{1,2,3,4,1});
		pl.add(11,new int[]{1,2,3,4,5});

		s = " 5 ";
		s += "    |   ";
		s += " 0 ";
		s += "    |   ";
		s += "20 ";
		s += " \n--------------------------\n";
		s += "10 ";
		s += "    |   ";
		s += "20 ";
		s += "    |   ";
		s += "25 ";
		s += " \n--------------------------\n";
		s += "15 ";
		s += "    |   ";
		s += " 0 ";
		s += "    |   ";
		s += "30 ";
		s +=  " \n--------------------------\n       |   ";
		s += " "+0+" ";
		s +="   |\n       +----------+\n";
		assertEquals(s,pl.toString());
		
		pl.add(8,new int[]{1,2,3,4,4});
		pl.add(7,new int[]{3,3,3,4,4});

		s = " 5 ";
		s += "    |   ";
		s += "15 ";
		s += "    |   ";
		s += "20 ";
		s += " \n--------------------------\n";
		s += "10 ";
		s += "    |   ";
		s += " 0 ";
		s += "    |   ";
		s += "25 ";
		s += " \n--------------------------\n";
		s += "15 ";
		s += "    |   ";
		s += " 0 ";
		s += "    |   ";
		s += "30 ";
		s +=  " \n--------------------------\n       |   ";
		s += " "+0+" ";
		s +="   |\n       +----------+\n";
		assertEquals(s,pl.toString());
	}

}
