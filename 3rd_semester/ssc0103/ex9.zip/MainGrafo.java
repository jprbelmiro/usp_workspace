package poo.grafo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import poo.entradaTeclado.ETException;
import poo.entradaTeclado.EntradaTeclado;

public class MainGrafo {

	public static void main(String[] args) {
		//0. Variaveis
		int nVertices = 0, nArestas = 0;
		double peso = 0;
		String nome = null, origem = null, destino = null;
		List<Vertice> v = null;
		List<Aresta> a = null;
			v = new ArrayList<Vertice>();
			a = new ArrayList<Aresta>();
			
		//1. Apresentacao do programa e leitura das variaveis iniciais...
		System.out.println("| ------------------------ GRAFOS ------------------------");
		System.out.println("| Bem vindo ao programa que testa o algoritmo de Dijkstra.");
		System.out.println("| - Voce so podera testar um grafo por vez.");
		System.out.println("| - Os grafos sao direcionados e ponderados.");
		System.out.println("| - Os pesos das arestas devem ser positivos maiores que 0.");
		
		System.out.printf(":: Informe o numero de VERTICE do seu grafo: ");
		try {nVertices = EntradaTeclado.leInt();}catch (IOException e){e.printStackTrace();}
		
		System.out.printf(":: Informe o numero de ARESTAS do seu grafo: ");
		try {nArestas = EntradaTeclado.leInt();}catch (IOException e){e.printStackTrace();}
		
		for(int i = 0 ; i < nVertices ; i++){
			System.out.printf("V >> Informe o NOME do seu VERTICE %d: ",i+1);
			try {
				nome = EntradaTeclado.leString();
			}catch (ETException e) {e.printStackTrace();}
			catch (IOException e){e.printStackTrace();}
			
			v.add(new Vertice(nome));
		}
		for(int i = 0 ; i < nArestas ; i++){
			System.out.printf("A >> Informe a ORIGEM do seu ARESTA %d: ",i+1);
			try {
				origem = EntradaTeclado.leString();
			}catch (ETException e) {e.printStackTrace();}
			catch (IOException e){e.printStackTrace();}
			
			System.out.printf("A >> Informe o DESTINO do seu ARESTA %d: ",i+1);
			try {
				destino = EntradaTeclado.leString();
			}catch (ETException e) {e.printStackTrace();}
			catch (IOException e){e.printStackTrace();}
			
			System.out.printf("A >> Informe o PESO do seu ARESTA %d: ",i+1);
			try {
				peso = EntradaTeclado.leDouble();
			}
			catch (IOException e){e.printStackTrace();}
			
			try {
				a.add(new Aresta(origem,destino,peso));
			} catch (ArestaException e) {
				e.printStackTrace();
			}
		}
		
		//2. Aplicando o Algoritmo de Dijkstra em cima do grafo criado e imprimindo
		//o caminho encontrado...
		System.out.printf(":: Informe o vertice de ORIGEM para o algoritmo: ");
		try {
			origem = EntradaTeclado.leString();
		}catch (ETException e) {e.printStackTrace();}
		catch (IOException e){e.printStackTrace();}
		
		Grafo G = new Grafo(v,a);
		Dijkstra D = new Dijkstra(G);
			D.apply(new Vertice(origem));
			
		//3. Exibindo o resultado... 
		LinkedList<Vertice> caminho = D.getCaminho(new Vertice("3"));
		System.out.printf("\n");
		if(caminho.isEmpty()) System.out.printf("----- Vazio -----\n");
		else for(Vertice vert : caminho)
			System.out.printf(vert.toString() + " ");
			
		//4. Imprimindo na tela uma mensagem de encerramento do programa...
		System.out.println("| Obrigado por utilizar nosso sistema de teste do Algoritmo");
		System.out.println("|de Dijkstra.");
		System.out.println("|nome: Matheus Aparecido do Carmo Alves  -   no usp: 9791114");	
		System.out.println("-------------------------------------------------------------");
	}

}
