package poo.grafo;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class Dijkstra {

	private Grafo G;
    private Set<Vertice> S;				//Colocados na arvore
    private Set<Vertice> U;				//Retirados da fila
    private Map<Vertice, Vertice> PI;	//Predecessores
    private Map<Vertice, Integer> D;	//Distancia
	private List<Vertice> verticesAdjacentes;
	
    public LinkedList<Vertice> getCaminho(Vertice v) {
        LinkedList<Vertice> caminho = new LinkedList<Vertice>();
        Vertice u = v;
        //check if a path exists
        if (PI.get(u) == null) {
            return caminho;
        }
        caminho.add(u);
        while (PI.get(u) != null) {
            u = PI.get(u);
            caminho.add(u);
        }
        // Put it into the correct order
        Collections.reverse(caminho);
        return caminho;
    }
	

    
    private int getMenorD(Vertice destino) {
        Integer d = D.get(destino);
        if(d == null)
            return Integer.MAX_VALUE;
        else
        	return d;
    }
    

    
    private Vertice vizinhoMinimo(Set<Vertice> v) {
        Vertice min = null;
        for (Vertice u : v){
            if (min == null)
                min = u;
            else if (getMenorD(u) < getMenorD(min))
                    min = u;
        }
        return min;
    } 
    
    private int getD(Vertice v, Vertice u) {
        for (Aresta a : G.getAresta()) {
            if (a.getOrigem().equals(v) && a.getDestino().equals(u))
                return (int) a.getValor();
        }
        throw new RuntimeException("Should not happen");
    }
    
    public void distanciaMinima(Vertice v){
    	//1. Construindo a lista de vizinhos
    	verticesAdjacentes = new ArrayList<Vertice>();
        for (Aresta a : G.getAresta()) {
            if (a.getOrigem().equals(v) && !(S.contains(a.getDestino())))
            	verticesAdjacentes.add(a.getDestino());
        }
        
        //2. Procurando pelo vizinho de menor peso
        for (Vertice u : verticesAdjacentes){
            if(getMenorD(u) > getMenorD(v) + getD(v, u)){
            	D.put(u, getMenorD(v) + getD(v, u));
                PI.put(u, v);
                U.add(u);
            }
        }
    }
    
    public void apply(Vertice origem) {
    	//0. Inicializando as variaveis...
        S = new HashSet<Vertice>();
        U = new HashSet<Vertice>();
        D = new HashMap<Vertice, Integer>();
        PI = new HashMap<Vertice, Vertice>();
        
        //1. Iniciando o processo marcando o ponto de partida
        //- ie, colocando a distancia no ponto de origem como 0
        //e adicionando-o no conjuntos de vertices ja vizitados...
        D.put(origem, 0);
        U.add(origem);
        
        //2. Iniciando o algoritmo de Dijkstra...
        while (U.size() > 0) {
            Vertice v = vizinhoMinimo(U);
            S.add(v);
            U.remove(v);
            distanciaMinima(v);
        }
    }
	
	public Dijkstra(Grafo G) {
        this.G = G;
    }
	
}
