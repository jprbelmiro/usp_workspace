package poo.grafo;

public class Aresta extends Vertice{
	
	private Vertice origem;
	private Vertice destino;
	private double valor;

	@Override
    public String toString() {
        return "(" + origem + "," + destino + ")";
    }
	
	protected Vertice getOrigem() {
		return origem;
	}

	protected void setOrigem(Vertice origem) {
		this.origem = origem;
	}

	protected Vertice getDestino() {
		return destino;
	}

	protected void setDestino(Vertice destino) {
		this.destino = destino;
	}

	protected double getValor() {
		return valor;
	}

	protected void setValor(double valor) {
		this.valor = valor;
	}
	
	public Aresta(String v1, String v2, int valor) throws ArestaException{
		if(valor <= 0 )
			throw new ArestaException(":: Invalid value to the Edge (value <= 0) ::\n");
		else
			this.valor = valor;
		this.origem = new Vertice(v1);
		this.destino = new Vertice(v2);;
	}
	
	public Aresta(String v1, String v2, float valor) throws ArestaException{
		if(valor <= 0 )
			throw new ArestaException(":: Invalid value to the Edge (value <= 0) ::\n");
		else
			this.valor = valor;
		this.origem = new Vertice(v1);
		this.destino = new Vertice(v2);;
	}
	
	public Aresta(String v1, String v2, double valor) throws ArestaException{
		if(valor <= 0 )
			throw new ArestaException(":: Invalid value to the Edge (value <= 0) ::\n");
		else
			this.valor = valor;
		this.origem = new Vertice(v1);
		this.destino = new Vertice(v2);;
	}
	
	public Aresta(){
		valor = 1;
		this.origem = new Vertice("v1");
		this.destino = new Vertice("v2");;
	}
	
}
