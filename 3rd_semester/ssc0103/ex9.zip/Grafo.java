package poo.grafo;

import java.util.HashSet;
import java.util.List;

public class Grafo extends HashSet<Aresta>{
	private static final long serialVersionUID = 1L;

	private final List<Vertice> vertices;
    private final List<Aresta> arestas;

    public List<Vertice>  getVertices() {
        return vertices;
    }

    public List<Aresta> getAresta() {
        return arestas;
    }
    
    public Grafo(List<Vertice>  vertices, List<Aresta> aresta) {
    	super();
    	for(Aresta a : aresta)
    		add(a);
    	
        this.vertices = vertices;
        this.arestas = aresta;
    }
}
