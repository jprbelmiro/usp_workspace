package poo.grafo;

public class ArestaException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public ArestaException(String mensagem) {
		super(mensagem);
	}

}
