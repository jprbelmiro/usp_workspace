package poo.grafo;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

public class GeneralTest {

// DIJKSTRA -----------------------------------------------------------------------
	@Test
	public void testGetCaminho() throws ArestaException {
		List<Vertice> v = new ArrayList<Vertice>();
		List<Aresta> a = new ArrayList<Aresta>();
			v.add(new Vertice("1"));
			v.add(new Vertice("2"));
			v.add(new Vertice("3"));
			a.add(new Aresta("1","2",10));
			a.add(new Aresta("2","3",20));
		Grafo G = new Grafo(v,a);
		Dijkstra D = new Dijkstra(G);
		D.apply(new Vertice("1"));
		LinkedList<Vertice> caminho = D.getCaminho(new Vertice("1"));
		assertNotEquals(caminho,null);
	}

	@Test
	public void testApply() throws ArestaException {
		List<Vertice> v = new ArrayList<Vertice>();
		List<Aresta> a = new ArrayList<Aresta>();
			v.add(new Vertice("1"));
			v.add(new Vertice("2"));
			v.add(new Vertice("3"));
			v.add(new Vertice("4"));
			v.add(new Vertice("5"));
			v.add(new Vertice("6"));
			a.add(new Aresta("1","2",10));
			a.add(new Aresta("2","3",20));
			a.add(new Aresta("2","4",3));
			a.add(new Aresta("2","5",4));
			a.add(new Aresta("5","3",22));
			a.add(new Aresta("4","5",12));
		Grafo G = new Grafo(v,a);
		Dijkstra D = new Dijkstra(G);
		D.apply(new Vertice("1"));
		assertNotEquals(D,null);
	}

	@Test
	public void testDijkstra() throws ArestaException {
		List<Vertice> v = new ArrayList<Vertice>();
		List<Aresta> a = new ArrayList<Aresta>();
			v.add(new Vertice("1"));
			v.add(new Vertice("2"));
			v.add(new Vertice("3"));
			a.add(new Aresta("1","2",10));
			a.add(new Aresta("2","3",20));
		Grafo G = new Grafo(v,a);
		Dijkstra D = new Dijkstra(G);
		assertNotEquals(D,null);
	}

	
// VERTICE ----------------------------------------------------------------------------- 
	@Test
	public void testEquals() {
		Vertice v = new Vertice("A");
		assertEquals(v.equals(v),true);
		
		v = new Vertice();
		Vertice o = new Vertice("A");
		assertEquals(v.equals(o),false);
		
		v = new Vertice("A");
		assertEquals(v.equals(o),true);
		
		o = new Vertice("B");
		assertEquals(v.equals(o),false);
		
		o = new Vertice();
		assertEquals(v.equals(o),false);
		
		Aresta e = new Aresta();
		assertEquals(v.equals(e),false);
	}
	
	@Test
	public void testToString() {
		Vertice v = new Vertice("A");
		assertEquals(v.toString(),"A");
	}
	
	@Test
	public void testGetNome() {
		Vertice v = new Vertice("A");
		assertEquals(v.getNome(),"A");
	}

	@Test
	public void testSetNome() {
		Vertice v = new Vertice();
			v.setNome("A");
		assertEquals(v.getNome(),"A");
	}

	@Test
	public void testVertice() {
		Vertice v = new Vertice();
		assertNotEquals(v,null);
	}

// ARESTA ---------------------------------------------------------------------------------------------------------------------------
	@Test
	public void testToStringA() throws ArestaException {
		Aresta a = new Aresta("A","B",10);
		assertEquals(a.toString(),"(A,B)");
	}
	
	@Test
	public void testGetValor() {
		Aresta a = new Aresta();
		assertEquals(a.getValor(),1,0.01);
	}

	@Test
	public void testSetValor() {
		Aresta a = new Aresta();
			a.setValor(10);
		assertEquals(a.getValor(),10,0.01);
	}

	@Test
	public void testGetV1() {
		Aresta a = new Aresta();
		Vertice v1 = new Vertice();
			a.setOrigem(v1);
		assertEquals(a.getOrigem(),v1);
	}

	@Test
	public void testSetV1() {
		Aresta a = new Aresta();
		Vertice v1 = new Vertice();
			a.setOrigem(v1);
		assertEquals(a.getOrigem(),v1);
	}

	@Test
	public void testGetV2() {
		Aresta a = new Aresta();
		Vertice v2 = new Vertice();
			a.setDestino(v2);
		assertEquals(a.getDestino(),v2);
	}

	@Test
	public void testSetV2() {
		Aresta a = new Aresta();
		Vertice v2 = new Vertice();
			a.setDestino(v2);
		assertEquals(a.getDestino(),v2);
	}

	@Test(expected=ArestaException.class)
	public void testIntException() throws ArestaException {
		new Aresta("v1","v2",0);
	}
	
	@Test(expected=ArestaException.class)
	public void testFloatException() throws ArestaException {
		new Aresta("v1","v2",(float)0.0);
	}
	
	@Test(expected=ArestaException.class)
	public void testDoubleException() throws ArestaException {
		new Aresta("v1","v2",0.0);
	}
	
	@Test
	public void testArestaStringStringInt() throws ArestaException {
		Aresta a = new Aresta("v1","v2",(int)10);
		
		assertNotEquals(a,null);
		assertNotEquals(a.getOrigem(),null);
		assertNotEquals(a.getDestino(),null);
		assertEquals((int)a.getValor(),10);
	}

	@Test
	public void testArestaStringStringFloat() throws ArestaException {
		Aresta a = new Aresta("v1","v2",(float)10.0);
		
		assertNotEquals(a,null);
		assertNotEquals(a.getOrigem(),null);
		assertNotEquals(a.getDestino(),null);
		assertEquals((float)a.getValor(),10,0.01);
	}
	
	@Test
	public void testArestaStringStringDouble() throws ArestaException {
		Aresta a = null;
			a = new Aresta("v1","v2",10.0);
			
		assertNotEquals(a,null);
		assertNotEquals(a.getOrigem(),null);
		assertNotEquals(a.getDestino(),null);
		assertEquals(a.getValor(),10,0.01);
	}

	@Test
	public void testAresta() {
		Aresta a = new Aresta();
		assertNotEquals(a,null);
	}

}
