package poo.entradaTeclado;

import java.io.IOException;

public class ETException extends IOException {	

	private static final long serialVersionUID = 1L;

	public ETException(String message){
		super(message);
	}

}
