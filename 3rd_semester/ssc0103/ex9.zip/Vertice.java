package poo.grafo;

public class Vertice {
	
	private String nome;
	
	@Override
    public boolean equals(Object obj) {
		 if(this == obj) return true;
	     if(obj == null) return false;
	     if(getClass() != obj.getClass()) return false;
	     
		 Vertice outro = (Vertice) obj;
         if (nome == null && outro.nome != null) return false;
         else if (!nome.equals(outro.nome)) return false;
         else return true;
    }
	
    @Override
    public String toString() {
        return nome;
    }
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}	
	
	public Vertice(String nome){
		this.nome = nome;
	}
	
	public Vertice(){
		nome = null;
	}
	
}
