package poo.baralho;

import poo.Random;

/**
* Esta classe foi desenhada para representar uma carta de baralho.
* Possui como atributos valor, naipe e um gerador de numeros aleatorios.
* Dessa forma é possivel criar de forma bem generalizada, jogos que 
* envolvam cartas.
* 
* @author miçanga
* @author lekao
*/
public class Carta {
	
	private static final int INVALID = -1;
	
	protected static final int PAUS = 3;
	protected static final int COPAS = 2;
	protected static final int ESPADAS = 1;
	protected static final int OURO = 0;

	protected int A = 12;
	protected int K = 11;
	protected int J = 10;
	protected int Q = 9;
	protected int DEZ = 8;
	protected int NOVE = 7;
	protected int OITO = 6;
	protected int SETE = 5;
	protected int SEIS = 4;
	protected int CINCO = 3;
	protected int QUATRO = 2;
	protected int TRES = 1;
	protected int DOIS = 0;
	
	private int valor;
	private int naipe;
	private Random r;
	
	/**
	* Essa função é responsavel por retornar
	* em forma de string o valor de uma carta.
	* @return o valor no formato de string de
	* uma carta.
	*/
	protected String getValorString(){
		if(valor == A) return "A ";
		else if(valor == K) return "K ";
		else if(valor == J) return "J ";
		else if(valor == Q) return "Q ";
		else if(valor == DEZ) return "10";
		else if(valor == NOVE) return "9 ";
		else if(valor == OITO) return "8 ";
		else if(valor == SETE) return "7 ";
		else if(valor == SEIS) return "6 ";
		else if(valor == CINCO) return "5 ";
		else if(valor == QUATRO) return "4 ";
		else if(valor == TRES) return "3 ";
		return "2 ";
	}
	
	/**
	* Esse metodo é responsavel por retornar
	* em forma de string o naipe de uma carta.
	* @return o naipe no formato de string de
	* uma carta.
	*/
	protected char getNaipeChar(){
		if(naipe == PAUS) return '♣';
		else if(naipe == COPAS) return '♥';
		else if(naipe == OURO) return '♠';
		return '♦';
	}
	
	/**
	* Esse metodo é responsavel por retornar
	* como inteiro o naipe de uma carta.
	* @return o naipe (int) de uma carta.
	*/
	public int getNaipe(){
		return naipe;
	}
	
	/**
	* Esse metodo é responsavel por determinar
	* o naipe de uma carta, 'setando' o valor 
	* passado como parametro.
	*/
	protected void setNaipe(int n){
		naipe = n;
		return;
	}
	
	/**
	* Essa função é responsavel por retornar
	* como inteiro o valor de uma carta.
	* @return o valor (int) de uma carta
	*/
	public int getValor(){
		return valor;
	}
	
	/**
	* Esse metodo é responsavel por determinar
	* o valor de uma carta, 'setando' o valor 
	* passado como parametro.
	*/
	protected void setValor(int v){
		valor = v;
		return;
	}
	
	/**
	* Metodo responsavel pela criacao de uma
	* carta a partir de uma string passada como
	* parametro.
	* A string deve conter, respectivamente, o 
	* valor da carta e o naipe desta (escrito)
	* separados por espaço, virgula ou ponto-e-virgula 
	* para ocorrer a criação. Em caso de erro,
	* é retornada uma carta invalida.
	* Exemplo de string: "A 12"
	* @return carta criada com os parametros passados
	* caso seja obedecida a norma da string. Caso
	* contrario, retorna-se uma carta invalida.
	*/
	public Carta(String str){
		if(str.matches("^\\s*[a-zA-Z2-10]{1,2}[\\s,;]+[a-zA-Z]{4,7}\\s*$")){
			if(str.matches("^\\s*[Aa]{1}")) valor = A;
			else if(str.matches("^\\s*[Kk]{1}")) valor = K;
			else if(str.matches("^\\s*[Jj]{1}")) valor = J;
			else if(str.matches("^\\s*[Qq]{1}")) valor = Q;
			else if(str.matches("^\\s*[10]{1}")) valor = DEZ;
			else if(str.matches("^\\s*[9]{1}")) valor = NOVE;
			else if(str.matches("^\\s*[8]{1}")) valor = OITO;
			else if(str.matches("^\\s*[7]{1}")) valor = SETE;
			else if(str.matches("^\\s*[6]{1}")) valor = SEIS;
			else if(str.matches("^\\s*[5]{1}")) valor = CINCO;
			else if(str.matches("^\\s*[4]{1}")) valor = QUATRO;
			else if(str.matches("^\\s*[3]{1}")) valor = TRES;
			else if(str.matches("^\\s*[2]{1}")) valor = DOIS;
			else valor = INVALID;
			
			
			if(str.matches("[\\s,;]+[Pp][Aa][Uu][Ss]\\s*$")) naipe = PAUS;
			else if(str.matches("[\\s,;]+[Cc][Oo][Pp][Aa][Ss]\\s*$")) naipe = COPAS;
			else if(str.matches("[\\s,;]+[Es][Ss][Pp][Aa][Dd][Aa][Ss]\\s*$")) naipe = ESPADAS;
			else if(str.matches("[\\s,;]+[Oo][Uu][Rr][Oo]\\s*$")) naipe = OURO;
			else naipe = INVALID;
		}
		else if(str.matches("^\\s*[a-zA-Z]{4,7}[\\s,;]+[a-zA-Z2-10]{1,2}$"));
	}
	
	/**
	* Metodo responsavel pela criacao de uma
	* carta a partir de parametros passados ao
	* metodo.
	* O primeiro parametro passado é o valor da
	* carta e o segundo é seu naipe, ambos passados
	* como inteiro.
	* @return carta criada com os parametros passados.
	*/
	public Carta(int v, int n){
		valor = v;
		naipe = n;
	}
	
	/**
	* Metodo responsavel pela criacao de uma
	* carta aleatoria.
	* @return carta aleatoria.
	*/
	public Carta(){
		r = new Random();
		valor = r.getIntRand(12);
		naipe = r.getIntRand(3);
	}
	
}
