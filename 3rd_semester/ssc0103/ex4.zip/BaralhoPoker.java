package poo.baralho;

/**
* Esta classe foi desenhada para representar um baralho de
* poker, sendo ela filha da classe Baralho, que representaria
* a classe principal dos Baralhos possiveis para se criar.
* 
* @author miçanga
* @author lekao
*/
public class BaralhoPoker extends Baralho{
	
	/**
	* Metodo responsavel por imprimir na tela a
	* mao atual de um jogador de poker.
	* A mao de cartas deve ser passada como parametro
	* ao metodo.
	*/
	public void printMao(Carta[] carta){
		System.out.printf("+------+   +------+   +------+   +------+   +------+\n");
		System.out.printf("+%c     +   +%c     +   +%c     +   +%c     +   +%c     +\n",carta[0].getNaipeChar(),carta[1].getNaipeChar(),
													carta[2].getNaipeChar(),carta[3].getNaipeChar(),carta[4].getNaipeChar());
		System.out.printf("+  %s  +   +  %s  +   +  %s  +   +  %s  +   +  %s  +\n",carta[0].getValorString(),carta[1].getValorString(),
														carta[2].getValorString(),carta[3].getValorString(),carta[4].getValorString());
		System.out.printf("+    %c +   +    %c +   +    %c +   +    %c +   +    %c +\n",carta[0].getNaipeChar(),carta[1].getNaipeChar(),
													carta[2].getNaipeChar(),carta[3].getNaipeChar(),carta[4].getNaipeChar());
		System.out.printf("+------+   +------+   +------+   +------+   +------+\n\n");
	}
	
	/**
	* Metodo responsavel por trocar uma carta especifica
	* da mao de um jogador de poker.
	* É passado como parametro ao metodo uma string que
	* contem o numero das cartas que deseja-se alterar.
	* As cartas serao trocadas por outras geradas aleatoriamente.
	* @return uma nova mao de cartas (Carta[]).
	*/
	public Carta[] trocaCartaMao(String str){
		Carta[] mao = new Carta[5];
		for(int i = 0 ; i < 5 ; i++){
			mao[i] = getCarta();
			try{Thread.sleep(25);}catch(Exception e){}
		}
		return mao;
	}
	
	/**
	* Metodo responsavel por gerar uma nova mao de
	* cartas de poker.
	* Essa mao conterá somente cartas geradas aleatoriamente.
	*/
	public Carta[] novaMao(){
		Carta[] mao = new Carta[5];
		for(int i = 0 ; i < 5 ; i++){
			mao[i] = getCarta();
			try{Thread.sleep(100);}catch(Exception e){}
		}
		return mao;
	}
	
	/**
	* Metodo responsavel por criar um baralho de poker
	* usual, contendo 52 cartas onde a carta mais fraca 
	* é o dois e a mais forte são os Ás.
	* Inicialmente, nenhuma carta é marcada como usado.
	*/
	public BaralhoPoker(){
		ncartas = 52;
		cartas = new Carta[52];
		cartaUsada = new boolean[52];
		
		A = 12;
		K = 11;
		Q = 10;
		J = 9;
		DEZ = 8;
		NOVE = 7;
		OITO = 6;
		SETE = 5;
		SEIS = 4;
		CINCO = 3;
		QUATRO = 2;
		TRES = 1;
		DOIS = 0;
		
		int counter = 0;
		for(int valor = 0 ; valor < 13 ; valor++){
			for(int naipe = 0 ; naipe < 4; naipe++){
				cartas[counter] = new Carta(valor,naipe);
				cartaUsada[counter++] = false;
			}
		}
			
	}
}
