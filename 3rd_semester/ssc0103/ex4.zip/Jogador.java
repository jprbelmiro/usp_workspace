package poo.baralho;

/**
* Esta classe foi desenhada para representar um jogador de video
* poker, contendo como atributos o numero de cartas na mao, as
* cartas que segura e os creditos para serem gastos no jogo.
* 
* @author miçanga
* @author lekao
*/
public class Jogador {
	private int ncards;
	private int credit;
	private Carta[] mao;

	/**
	* Realiza uma aposta para o jogador a partir de um
	* parametro passado que representa o valor da aposta.
	* @return um valor maior ou igual a zero caso a 
	* a aposta tenha sido bem sucessida. Caso contrario
	* retorna-se -1.
	*/
	public int apostar(int aposta){
		if(aposta > 0 && aposta <= credit) return credit -= aposta;
		else return -1;
	}
	
	/**
	* Atualiza o credito da classe jogador.
	*/
	public void atualizaCredito(int resultado){
		credit += resultado;
		return;
	}
	
	/**
	* Insere uma carta passada como parametro
	* em uma posicao especifica da mao do jogador
	* também passada como parametro do metodo.
	*/
	public void setCartaNaMao(int n, Carta c){
		mao[n] = c;
		return;
	}
	
	/**
	* Retorna a mao de cartas do jogador.
	* @return Carta[] que representa
	* a mao de cartas do jogador.
	*/
	public Carta[] getMao(){
		return mao;
	}
	
	/**
	* Insere um conjunto de cartas como
	* nova mao de cartas do jogador.
	*/
	public void setMao(Carta[] c){
		for(int i = 0 ; i < ncards ; i++){
			mao[i] = c[i];
		}
	}
	
	/**
	* Retorna a quantidade de creditos da classe jogador.
	* @return quantidade de creditos do jogador.
	*/
	public int getCredit(){
		return credit;
	}
	
	/**
	* Insere um valor predeterminado passado como parametro
	* do metodo para o valor de credito do jogador.
	*/
	public void setCredit(int c){
		credit = c;
		return;
	}
	
	/**
	* Retorna o numero de cartas na mao do jogador
	* @return numero de cartas na mao do jogador
	*/
	public int getNCards(){
		return ncards;
	}
		
	/**
	* Metodo responsavel por determinar o numero de cartas
	* na mao de um jogador.
	* Esse numero é passado como parametro no metodo.
	*/
	public void setNCards(int n){
		ncards = n;
		return;
	}
	
	/**
	* Metodo responsavel por criar um jogador predeterminado
	* pelos parametros.
	* É passado como parametro o numero de cartas na mao do
	* jogador, as cartas que ele irá segurar e a sua quantidade
	* de creditos inicial.
	*/
	public Jogador(int n, int c, Carta[] cards){
		ncards = n;
		credit = c;
		mao = cards;
	}
	
	/**
	* Metodo responsavel por criar um jogador padrao do 
	* jogo de poker.
	*/
	public Jogador(){
		ncards = 5;
		credit = 200;
		mao = new Carta[5];
	}
	
}
