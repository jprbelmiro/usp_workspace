package poo.baralho;

/**
* Esta classe foi desenhada para representar a classe mae
* dos Baralhos de jogos de carta. Ela possui todos os 
* atributos necessarios para a criacao de um baralho de
* jogo.
* Ela extende a classe Carta, quem "compoe" o baralho.
* 
* @author miçanga
* @author lekao
*/
public class Baralho extends Carta{

	protected int ncartas;
	protected Carta[] cartas;
	protected boolean[] cartaUsada;
	
	/**
	* Metodo responsavel por retornar uma string
	* que imprime todas as cartas pertencente ao
	* baralho em lista.
	* @return string com todas as cartas do baralho.
	*/
	@Override
	public String toString(){
		String str = null;
		
		for(int i = 0; i < 13 ; i++){
			for(int j = 0 ; j < 4 ; j++){
				if(cartas[i*4+j].getValor() == A)
					System.out.printf("A ");
				else if(cartas[i*4+j].getValor() == K)
					System.out.printf("K ");
				else if(cartas[i*4+j].getValor() == J)
					System.out.printf("J ");
				else if(cartas[i*4+j].getValor() == Q)
					System.out.printf("Q ");
				else if(cartas[i*4+j].getValor() == DEZ)
					System.out.printf("10 ");
				else if(cartas[i*4+j].getValor() == NOVE)
					System.out.printf("9 ");
				else if(cartas[i*4+j].getValor() == OITO)
					System.out.printf("8 ");
				else if(cartas[i*4+j].getValor() == SETE)
					System.out.printf("7 ");
				else if(cartas[i*4+j].getValor() == SEIS)
					System.out.printf("6 ");
				else if(cartas[i*4+j].getValor() == CINCO)
					System.out.printf("5 ");
				else if(cartas[i*4+j].getValor() == QUATRO)
					System.out.printf("4 ");
				else if(cartas[i*4+j].getValor() == TRES)
					System.out.printf("3 ");
				else if(cartas[i*4+j].getValor() == DOIS)
					System.out.printf("2 ");
				else System.out.printf("X ");
				
				if(cartas[i*4+j].getNaipe() == PAUS)
					System.out.printf("♣\n");
				else if(cartas[i*4+j].getNaipe() == COPAS)
					System.out.printf("♥\n");
				else if(cartas[i*4+j].getNaipe() == ESPADAS)
					System.out.printf("♠\n");
				else if(cartas[i*4+j].getNaipe() == OURO)
					System.out.printf("♦\n");
				else System.out.printf("○\n");
					
			}System.out.printf("\n");
		}
			
		
		return str;
	}
	
	/**
	* Metodo responsavel pela criacao de uma
	* carta a partir de parametros passados ao
	* metodo.
	* O primeiro parametro passado é o valor da
	* carta e o segundo é seu naipe, ambos passados
	* como inteiro.
	* @return carta criada com os parametros passados.
	*/
	public boolean isValid(Carta c){
		if(cartaUsada[(c.getValor()*4)+c.getNaipe()]) return false;
		return true;
	}
	
	/**
	* Metodo responsavel por recolocar todas as
	* cartas no baralho novamente, ou seja, resetar
	* o vetor de uso das cartas.
	*/
	public void restartBaralho(){
		for(int i = 0 ; i < ncartas ; i++)
			cartaUsada[i] = false;
		return;
	}
	
	/**
	* Metodo responsavel por devolver uma carta ao
	* baralho.
	*/
	public void devolveCarta(Carta c){
		cartaUsada[(c.getValor()*4)+c.getNaipe()] = false;
		return;
	}
	
	/**
	* Metodo responsavel por pegar uma carta especifica
	* do baralho. Caso ela nao tenha sido pega, ela é
	* retornada. Caso contrario, retorna-se null.
	* @return uma carta do baralho especifica caso
	* esta nao tenha sido usada. Caso tenha sido, retorna-se
	* null.
	*/
	public Carta getCarta(int v, int n){
		if(cartaUsada[(v*4)+n]) return null;
		else cartaUsada[(v*4)+n] = true;
		return new Carta(v,n);
	}
	
	/**
	* Metodo responsavel por pegar uma carta do baralho
	* e retorna-la, marcando-a como usada.
	* @return uma carta do baralho nao usada.
	*/
	public Carta getCarta(){
		Carta c = new Carta();
		if(cartaUsada[(c.getValor()*4)+c.getNaipe()]) return getCarta();
		else cartaUsada[(c.getValor()*4)+c.getNaipe()] = true;
		return c;
	}
	
	/**
	* Metodo responsavel pela criacao de um 
	* baralho padrao, ou seja, com todas as cartas.
	*/
	public Baralho(){
		ncartas = 52;
		cartas = new Carta[52];
		cartaUsada = new boolean[52];
		
		int counter = 0;
		for(int valor = 0 ; valor < 13 ; valor++){
			for(int naipe = 0 ; naipe < 4; naipe++){
				cartas[counter] = new Carta(valor,naipe);
				cartaUsada[counter++] = false;
			}
		}

	}
	
}
