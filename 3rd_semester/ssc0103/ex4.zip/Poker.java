package poo.baralho;

import poo.EntradaTeclado;

public class Poker {
	
	private static final String WELCOME = "|     |>|>|>|>|>|>|    POKER: THE GAME    |<|<|<|<|<|<|         |\n"
										+ "| Bem vindo ao programa que te permite jogar Poker (Video-Poker)|\n\n";
	private static final String BYE = "| Obrigado por ter utilizado nosso programa. Esperamos que tenha|\n"
										+ "|se divertido. Até a proxima!                                   |\n"
										+ "|Alunos: Marcelo de Moraes carvalho da silva [9791048]          |\n"
										+ "|        Matheus Aparecido do Carmo Alves    [9791114]          |\n"
									    + "|     |>|>|>|>|>|>|    POKER: THE GAME    |<|<|<|<|<|<|         |\n";
	private static final String OPERACOES = "| 1. Apostar;\n"
										+ "| 2. Ver regras;\n"
										+ "| 3. Sair;\n> ";

	private static final String REGRAS_TXT =  "\n----------------REGRAS-------------\n"
												+ "| O baralho usado é um baralho convencional de 52 cartas, ordenadas de 2 até 10 e\n"
												+ "|depois J (valete), Q (dama), K (rei) e A (ás). Note que o A não serve como 1. Ou\n"
												+ "|seja, ele é a maior carta da sequência e não a menor.\n"
												+ "| Cada jogo inicia com o jogador recebendo uma quantidade fixa de créditos (200\n"
												+ "|créditos). Cada rodada inicia com o jogador apostando um certo número de créditos,\n"
												+ "|maior que zero e menor ou igual ao número de créditos que possui. Feito isso, o\n"
												+ "|jogador recebe cinco cartas e deve tentar fazer uma das combinações que lhe paguem\n"
												+ "|os prêmios. Para isso, o jogador pode escolher trocar de zero a cinco cartas que\n"
												+ "|recebeu. Em seguida, pode trocar mais uma vez as cartas para alcançar alguma\n"
												+ "|combinação.\n"
												+ "|As combinações que premiam o jogador, e os respectivos valores são os seguintes:\n"
												+ "|-Combinação ---- Prêmio --------\n"
												+ "| Dois pares      Valor da aposta\n|\n"
												+ "| Trinca          2 X valor da aposta\n|\n"
												+ "| Straight        5 X valor da aposta\n"
												+ "| -- 5 cartas seguidas de naipes diferentes\n|\n"
												+ "| Flush          10 X valor da aposta\n"
												+ "| -- 5 cartas do mesmo naipe não seguidas\n|\n"
												+ "| Full hando     20 X valor da aposta\n"
												+ "| -- Uma trinca e um par\n|\n"
												+ "| Quadra         50 X valor da aposta\n|\n"
												+ "| Straight Flush            100 X valor da aposta\n"
												+ "| -- 5 cartas seguidas do mesmo naipe\n|\n"
												+ "| Royal Straight Flush      200 X valor da aposta\n"
												+ "| -- 5 cartas seguidas do mesmo naipe de 10 até o As\n"
												+ "-----------------------------------\n";
	
	private static final int APOSTAR = 1;
	private static final int REGRAS = 2;
	private static final int SAIR = 3;

	public static Carta[] organizaMao(Carta[] mao){
		Carta aux;
		for(int i = 0; i < 5; i++){
			for(int j = 0; j < 5; j++){
				if(mao[i].getValor() > mao[j].getValor()){
					aux = mao[i];
					mao[i] = mao[j];
					mao[j] = aux;
				}
			}
		}
		return mao;
	}
	
	public static boolean isRSF(Carta[] mao){
		int naipe = mao[0].getNaipe();
		if(mao[4].getValor() == 8 &&
		   mao[3].getValor() == 9 &&
		   mao[2].getValor() == 10 &&
		   mao[1].getValor() == 11 &&
		   mao[0].getValor() == 12 &&
		   mao[4].getNaipe() == naipe &&
		   mao[3].getNaipe() == naipe &&
		   mao[2].getNaipe() == naipe &&
		   mao[1].getNaipe() == naipe &&
		   mao[0].getNaipe() == naipe)
			return true;
		return false;
	}
	
	public static boolean isSF(Carta[] mao){
		int counter = 0;
		for(int i = 0; i < 4 ; i++){
			if(mao[i].getNaipe() == mao[i+1].getNaipe() && mao[i].getValor() == mao[i+1].getValor()+1)
					counter++;
		}
		if(counter == 4) return true;
		return false;
	}

	public static boolean isQUADRA(Carta[] mao){
		int counter = 0;
		for(int i = 0 ; i < 4 ; i++){
			if(mao[i].getValor() == mao[i+1].getValor()) 
				counter++;
		}
		if(counter == 3) return true;
		else return false;
	}

	public static boolean isFH(Carta[] mao){
		int counter = 0, counter2 = 0;
		int[] frequencia = new int [13];
		for(int i = 0; i < 13 ; i++){
			frequencia[i] = 0;
		}
		
		for(int i = 0; i < 5; i++){
			frequencia[mao[i].getValor()]++;
		}
		
		for(int i = 0; i < 13 ; i++){
			if(frequencia[i] == 2) counter++;
			else if(frequencia[i] == 3) counter2++;
		}
		if(counter == 1 && counter2 == 1) return true;
		else return false;
	}
	
	public static boolean isFLUSH(Carta[] mao){
		int counter = 0;
		int naipe = mao[0].getNaipe();
		for(int i = 0 ; i < 5; i++) 
			if(mao[i].getNaipe() == naipe) counter++;
		if(counter == 5) return true;
		else return false;
	}

	public static boolean isSTRAIGHT(Carta[] mao){
		int counter = 0;
		for(int i = 0; i < 4; i++){
			if(mao[i].getValor() == mao[i+1].getValor()+1){
				counter++;
			}
		}
		if(counter == 4) return true;
		else return false;
	}

	public static boolean isTRINCA(Carta[] mao){
		int counter = 0;
		int[] frequencia = new int[13];
		for(int i = 0; i < 13 ; i++){
			frequencia[i] = 0;
		}
		for(int i = 0; i < 5; i++){
			frequencia[mao[i].getValor()]++;
		}
		for(int i = 0; i < 13; i++){
			if(frequencia[i] == 3) counter++;	
		}
		if(counter == 1) return true;
		return false;
	}
	
	public static boolean isPAR(Carta[] mao){
		int counter = 0;
		int[] frequencia = new int[13];
		for(int i = 0; i < 13 ; i++){
			frequencia[i] = 0;
		}
		for(int i = 0; i < 5; i++){
			frequencia[mao[i].getValor()]++;
		}
		for(int i = 0; i < 13; i++){
			if(frequencia[i] == 2) counter++;
		}
		if(counter >= 2) return true;
		return false;
	}
	
	public static int pegaPremio(Carta[] mao, int aposta, BaralhoPoker baralho){
		//1. Organiza a mao do jogador para facilitar a avaliação...
		mao = organizaMao(mao);
		baralho.printMao(mao);
		
		//a) Royal Straight Flush
		if(isRSF(mao)){
			System.out.println("| Voce fez um Royal Straight Flush!! Premio: " + aposta*200);
			return aposta*200;
		}
		
		//Straight Flush
		if(isSF(mao)){
			System.out.println("| Voce fez um Straight Flush!! Premio: " + aposta*100);
			return aposta*100;
		}
		
		//Quadra
		if(isQUADRA(mao)){
			System.out.println("| Voce fez uma Quadra!! Pr�mio: " + aposta*50);
			return aposta*50;
		}
		
		//Full hand
		if(isFH(mao)){
			System.out.println("| Voce fez um Full Hand!! Premio: " + aposta*20);
			return aposta*20;
		}
		
		//Flush
		if(isFLUSH(mao)){
			System.out.println("| Voce fez um Flush!! Premio: " + aposta*10);
			return aposta*10;
		}
		
		//Straight
		if(isSTRAIGHT(mao)){
			System.out.println("| Voce fez um Straight!! Premio: " + aposta*5);
			return aposta*5;
		}
		
		//Trinca
		if(isTRINCA(mao)){
			System.out.println("| Voce fez uma Trinca!! Premio: " + aposta*2);
			return aposta*2;
		}
		
		//Dois pares
		if(isPAR(mao)){
			System.out.println("| Voce fez Duas Duplas!! Premio: " + aposta);
			return aposta;
		}
		
		System.out.println("| Voce nao marcou pontos, tente denovo!!");
		return 0;
		
	}
	
	 public static void main(String[] args) {
		 int op = 0, aposta = 0;
		 Jogador player = new Jogador();
		 BaralhoPoker baralho = new BaralhoPoker();
		 
		 //1. Iniciando o jogo e deixando o usuario selecionar o que deseja fazer...
		 System.out.printf(WELCOME);
		 
		 //2. Iniciando o jogo que acontece ate o jogador desistir ou acabarem os creditos... 
		 while(op != SAIR  && player.getCredit() > 0){
			 
			 System.out.printf("| Você tem %d creditos.                                         \n",player.getCredit());
			 System.out.printf("|O que deseja fazer?                                            |\n" + OPERACOES);
			 try{op = EntradaTeclado.leInt();}catch(Exception e){};
			 
			 //A.i) Comecando a rodada...
			 if(op == APOSTAR){
				 //A.ii) Lendo a aposta do jogador enquanto ela for invalida...
				 System.out.println("\n|     |>|>|>|>|>|>|   RODADA DE POKER    |<|<|<|<|<|<|          |");
				 System.out.printf("Quanto voce deseja apostar? > ");
				 try{aposta = EntradaTeclado.leInt();}catch(Exception e){};
				 while(player.apostar(aposta) < 0){
					 if(aposta > player.getCredit()) 
						 System.out.printf("| Voce nao tem creditos suficientes para essa aposta!\n"
						 				   +"| Entre com outro valor: ");
					 try{aposta = EntradaTeclado.leInt();}catch(Exception e){};
				 }
				 
				 //A.iii) Distribuindo as cartas e imprimindo a mao do jogador...
				 player.setMao(baralho.novaMao());
				 baralho.printMao(player.getMao());
				 
				 //A.iv) Perguntando ao usuario o que ele deseja fazer...
				 int counter = 0;
				 String troca = null;
				 while(op != 2 && counter < 2){
					 System.out.printf("| O que deseja fazer? Voce tem direito a %d operacoes\n"
					 				  + "|1. Trocar cartas\n"
					 				  + "|2. Receber o premio referente a suas cartas\n> ",2-counter);
					 try{op = EntradaTeclado.leInt();}catch(Exception e){};
					 if(op == 1){
						 System.out.printf("\n|Quais cartas voce deseja trocar? > ");
						 try{troca = EntradaTeclado.leString();}catch(Exception e){};
								for(int i = 0 ; i < troca.length() ; i++){
									if(Character.isDigit(troca.charAt(i)) && 
									Character.getNumericValue(troca.charAt(i)) <= 5 &&
									Character.getNumericValue(troca.charAt(i)) > 0){
										player.setCartaNaMao(Character.getNumericValue(troca.charAt(i))-1,baralho.getCarta());
									}
								}
					 }
					 else if(op != 2){
						 System.out.println("| Comando invalido. Tente novamente.\n");
						 counter--;
					 }
					 counter++;
					 baralho.printMao(player.getMao());
				 }
				 
				 //A.v) Contabilizando o premio da rodada e encerrando-a...
				 player.atualizaCredito(pegaPremio(player.getMao(),aposta,baralho));
				 op = -1;
			 }
			 //B. Imprimindo as regras na tela...
			 else if(op == REGRAS){
				 System.out.println(REGRAS_TXT);
			 }
			 //C. Imprimindo uma mensagem de erro na tela...
			 else if(op != SAIR){
				 System.out.println("\n| Operacao invalida. Tenta novamente.\n");
			 }
			 //3. Resetando o baralho para os proximos jogos...
			 baralho.restartBaralho();
		}
		 
		//4. Encerrando o programa...
		 System.out.printf("\n\n| Voce encerrou a noite com %d creditos.\n",player.getCredit());
		 System.out.printf(BYE);
		 return;
	 }
}
