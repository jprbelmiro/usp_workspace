package poo.imagem;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class Imagem{
	
	private File arquivo;
	private BufferedImage imagem;
	
	private static final int AMARELO_CAASO = -3026479;
	private static final int BRANCO_BANDECO = 0xFF;
	
	@Override
	public String toString(){
		String s = "";
		for(int i = 0 ; i < imagem.getWidth() ; i++){
			for(int j = 0 ; j < imagem.getHeight() ; j++){
				Color c = new Color(imagem.getRGB(i,j));
				if(c.getBlue() == 255) s += 0 + " ";
				else s += 1 + " ";
			}s += '\n';
		}
		return s;
	}
	
	public int vizinhosBrancos(int[] ponto, int[][][] movxy){
		
		int[][][] vizinhos = new int[3][3][2];
		for(int i = 0 ; i < 3 ; i++){
			for(int j = 0 ; j < 3 ; j++){
				vizinhos[i][j][0] = ponto[0] + movxy[i][j][0];
				vizinhos[i][j][1] = ponto[1] + movxy[i][j][1];
			}
		}
		
		int brancos = 0;
		for(int i = 0 ; i < 3 ; i++){
			for(int j = 0 ; j < 3 ; j++){
				if((imagem.getRGB(vizinhos[i][j][0], vizinhos[i][j][1]) & 255) == BRANCO_BANDECO) brancos++;
			}
		}
		return brancos;
	}
	
	public int[] vizinhoNaBorda(int[][][] vizinhos, int[] primeiroPonto, int[][][] movxy){
		int max = 0, branco = 0, amarelo = 0;
		int[] vizinhoTOP = new int[2];
		
		for(int i = 0 ; i < 3 ; i++){
			for(int j = 0 ; j < 3 ; j++){
				int x = vizinhos[i][j][0];
				int y = vizinhos[i][j][1];
				final int[] ponto = {x,y};
				if((imagem.getRGB(vizinhos[i][j][0],vizinhos[i][j][1]) == -3026479)) amarelo++;
				if(amarelo == 3){
					vizinhoTOP = primeiroPonto;
					return vizinhoTOP;
				}
				
				if((imagem.getRGB(vizinhos[i][j][0],vizinhos[i][j][1]) != -3026479)
					&& ((imagem.getRGB(vizinhos[i][j][0],vizinhos[i][j][1]) & 255)  != BRANCO_BANDECO)){
						branco = vizinhosBrancos(ponto,movxy);
						if(branco > max){
							max = branco;
							vizinhoTOP[0] = x;
							vizinhoTOP[1] = y;
						}
				}
			}
		}
		return vizinhoTOP;
	}
	
	public int direcao(int[] pontoAtual, int[] proximoPonto, int[][][] movxy){
		for(int i = 0 ; i < 3 ; i++){
			for(int j = 0 ; j < 3 ; j++){
				if(proximoPonto[0] - (pontoAtual[0] + movxy[i][j][0]) == 0
					&& proximoPonto[1] - (pontoAtual[1] + movxy[i][j][1]) == 0){
					if(i == 0 && j == 0) return 3;	//noroeste
					else if(i == 0 && j == 1) return 2;	//norte
					else if(i == 0 && j == 2) return 1;	//nordeste
					else if(i == 1 && j == 0) return 4;	//oeste
					else if(i == 1 && j == 2) return 0;	//leste
					else if(i == 2 && j == 0) return 5;	//sudoeste
					else if(i == 2 && j == 1) return 6;	//sul
					else if(i == 2 && j == 2) return 7;	//sudeste
				}
			}
		}
			
		return -1;
	}
	
	public ArrayList<Integer> thinningCC(){
		//0. Variaveis e auxiliares...
		int[][][] movxy = new int[3][3][2];
		//a. noroeste...
		movxy[0][0][0] = -1;
		movxy[0][0][1] = -1;
		//b. cima...
		movxy[0][1][0] = 0;
		movxy[0][1][1] = -1;
		//c. nordeste...
		movxy[0][2][0] = 1;
		movxy[0][2][1] = -1;
		//d. esquerda...
		movxy[1][0][0] = -1;
		movxy[1][0][1] = 0;
		//e. posicao atual...
		movxy[1][1][0] = 0;
		movxy[1][1][1] = 0;
		//f. direita...
		movxy[1][2][0] = 1;
		movxy[1][2][1] = 0;
		//g. sudoeste...
		movxy[2][0][0] = -1;
		movxy[2][0][1] = 1;
		//h. baixo...
		movxy[2][1][0] = 0;
		movxy[2][1][1] = 1;
		//i. sudeste...
		movxy[2][2][0] = 1;
		movxy[2][2][1] = 1;
			
		//1. Descobrindo o primeiro ponto...
		int[] primeiroPonto = getPrimeiroPonto();
		int[] pontoAtual = primeiroPonto;
		int[] proximoPonto = null;
		
		//2. Iniciando o codigo em cadeia...
		//- o resultado sera armazenado em um vetor...
		boolean flag = true;
        ArrayList<Integer> borda = new ArrayList<Integer>();
		while(flag){	
			//a. Criando uma matriz de vizinhos para o primeiro ponto...
			int[][][] vizinhos = new int[3][3][2];
			for(int i = 0 ; i < 3 ; i++){
				for(int j = 0 ; j < 3 ; j++){
					vizinhos[i][j][0] = pontoAtual[0] + movxy[i][j][0];
					vizinhos[i][j][1] = pontoAtual[1] + movxy[i][j][1];
					
					if(vizinhos[i][j][0] < 0 || vizinhos[i][j][0] > imagem.getHeight()
						|| vizinhos[i][j][1] < 0 || vizinhos[i][j][0] > imagem.getWidth())
								vizinhos[i][j] = pontoAtual;
				}
			}
				
			//b. Pintando o ponto atual de amarelo CAASO para saber
			//que este ja foi visitado...
			setImagemPixel(pontoAtual,AMARELO_CAASO);
			
			//b. Descobrindo qual o vizinho com maior numero de pixels brancos
			//em sua volta para ser o proximo ponto...
			proximoPonto = vizinhoNaBorda(vizinhos, primeiroPonto,movxy);
			borda.add(direcao(pontoAtual,proximoPonto,movxy));
			
			//c. Passando para o proximo ponto...
			pontoAtual = proximoPonto;

			//d. Verificando se n�o foi realizada uma volta completa pela borda...
			if(pontoAtual == primeiroPonto)
				flag = false;
		}
					
		return borda;
	}

	public int tamanhoDaBorda(){
		ArrayList<Integer> borda = thinningCC();
		return borda.size();
	}
	
    public int getLargura(){
    	int counter, max = 0;

    	for(int i = 0 ; i < imagem.getWidth() ; i++){
    		counter = 0;
    		for(int j = 0 ; j < imagem.getHeight() ; j++){
    			Color c = new Color(imagem.getRGB(i,j));
    			if(c.getBlue() != 255) counter ++;
    			else{
    				if(counter > max) max = counter;
    				counter = 0;
    			}
    		}
    	}
    	return max;
	}
	
	public int getAltura(){
		int counter, max = 0;
	
		for(int i = 0 ; i < imagem.getHeight() ; i++){
			counter = 0;
			for(int j = 0 ; j < imagem.getWidth() ; j++){
				Color c = new Color(imagem.getRGB(i,j));
				if(c.getBlue() != 255) counter ++;
				else{
					if(counter > max) max = counter;
					counter = 0;
				}
			}
	}
	return max;
	}
	
	public int[] getPrimeiroPonto(){
		for(int y = 0 ; y < imagem.getHeight(); y++){
			for(int x = 0 ; x < imagem.getWidth() ; x++){
				int[] ponto = {x,y};
				if((imagem.getRGB(x,y) & 255) != BRANCO_BANDECO) return ponto;
			}
		}
		return null;
	}
	
	public int getImagemPixel(int[] pixel){
		return imagem.getRGB(pixel[0],pixel[1]);
	}

	public void setImagemPixel(int[] pixel, int x) {
		imagem.setRGB(pixel[0],pixel[1],x);
	}
	
	public BufferedImage getImagem(){
		return imagem;
	}

	public void setImagem(BufferedImage imagem) {
		this.imagem = imagem;
	}
	
	public File getArquivo() {
		return arquivo;
	}

	public void setArquivo(File arquivo) {
		this.arquivo = arquivo;
	}
	
	public Imagem(File arquivo) throws IOException{
		setImagem(ImageIO.read(arquivo));
	}
	
	public Imagem(String nomeDoArquivo) throws IOException{
		arquivo = new File(nomeDoArquivo);
		setImagem(ImageIO.read(arquivo));
	}
	
	public Imagem(){
		arquivo = null;
		setImagem(null);
	}
	
}
