package poo.imagem;

import static org.junit.Assert.*;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import org.junit.Test;

public class ImagemTest {

	private Imagem img;
	private BufferedImage bimg;
	private File arq;

	@Test
	public void testToString() throws IOException {
		img = new Imagem("resrc\\circulo.png");
		assertNotEquals("",img.toString());
	}
	
	@Test
	public void testTamanhoDaBorda() throws IOException{
		img = new Imagem("resrc\\circulo.png");
		assertEquals(52,img.tamanhoDaBorda());
	}
	
	@Test
	public void testThinningCCLinha1() throws IOException{
		img = new Imagem("resrc\\linha1.png");
		ArrayList<Integer> borda = img.thinningCC();
		assertEquals("[-1]",borda.toString());
	}
	
	@Test
	public void testThinningCCPonto() throws IOException{
		img = new Imagem("resrc\\ponto.png");
		ArrayList<Integer> borda = img.thinningCC();
		assertEquals("[-1]",borda.toString());
	}

	@Test
	public void testThinningCC() throws IOException{
		img = new Imagem("resrc\\circulo.png");
		ArrayList<Integer> borda = img.thinningCC();
		assertEquals("[0, 0, 0, 7, 0, 0, 7, 7, 7, 7, 6, 6, 7, 6, 6, 6, 5, 6, 6, 5, 5, 5, 5, 4, 4, 5, 4, 4, 4, 3, 4, 4, 3, 3, 3, 3, 2, 2, 3, 2, 2, 2, 1, 2, 2, 1, 1, 1, 1, 0, 0, 1]",borda.toString());
	}
	
	@Test
	public void testFindLargura() throws IOException {
		img = new Imagem("resrc\\circulo.png");		
		assertEquals(20, img.getLargura());
	}
	
	@Test
	public void testFindAltura() throws IOException {
		img = new Imagem("resrc\\circulo.png");		
		assertEquals(20, img.getAltura());
	}
	
	@Test
	public void testGetPrimeiroPontoBranco() throws IOException{
		img = new Imagem("resrc\\branco.png");
		int[] ponto = img.getPrimeiroPonto();
		assertEquals(null,ponto);
	}
	
	@Test
	public void testGetPrimeiroPonto() throws IOException{
		img = new Imagem("resrc\\circulo.png");
		int[] ponto = img.getPrimeiroPonto();
		assertEquals(23,ponto[0]);
		assertEquals(16,ponto[1]);
	}
	
	@Test
	public void testGetImagemPixel() throws IOException{
		img = new Imagem("resrc\\circulo.png");
		int[] ponto = {0,0};
		assertEquals(-1,img.getImagemPixel(ponto));
	}

	@Test
	public void testSetImagemPixel() throws IOException{
		img = new Imagem("resrc\\circulo.png");
		int[] ponto = {0,0};
		img.setImagemPixel(ponto,10);
		assertNotEquals(-1,img.getImagemPixel(ponto));
	}
	
	@Test
	public void testGetImagem() throws IOException {
		img = new Imagem("resrc\\circulo.png");
		assertNotEquals(null,img.getImagem());
	}

	@Test
	public void testSetImagem() throws IOException {
		img = new Imagem();
		arq = new File("resrc\\circulo.png");
		bimg = ImageIO.read(arq);
		img.setImagem(bimg);
		assertNotEquals(null,(img.getImagem()).getData());
	}

	@Test
	public void testGetArquivo() {
		arq = new File("resrc\\circulo.png");
		assertNotEquals(null,arq);
	}

	@Test
	public void testSetArquivo() {
		img = new Imagem();
		arq = new File("resrc\\oval.png");
		img.setArquivo(arq);
		assertNotEquals(null,img.getArquivo());
	}

	@Test
	public void testImagemFile() throws IOException  {
		arq = new File("resrc\\circulo.png");
		img = new Imagem(arq);
		assertNotEquals(null,img.getImagem());
	}

	@Test
	public void testImagemString() throws IOException  {
		img = new Imagem("resrc\\circulo.png");
		assertNotEquals(null,img.getImagem());
	}

	@Test
	public void testImagem() throws IOException {
		img = new Imagem();
		assertEquals(null,img.getImagem());
	}

}
