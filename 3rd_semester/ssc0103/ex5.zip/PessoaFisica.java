package poo.pessoa;

public class PessoaFisica extends Pessoa{

	private int idade;
	private long cpf;
	private float altura;
	private double peso;
	private String estadoCivil;
	private String dataDeNascimento;
	
	@Override
	public String toString(){
		String str = "Nome: " + nome 
				+ "\n- endereco: " + endereco
				+ "\n- email: " + email
				+ "\n- idade: " + idade
				+ "\n- altura: " + altura
				+ "\n- peso: " + peso
				+ "\n- estado civil: " + estadoCivil
				+ "\n- data de nascimento: " + dataDeNascimento + "\n";  
		return str; 
	}
	
	public int getIdade(){
		return idade;
	}
	
	public void setIdade(int num){
		idade = num;
		return;
	}

	public long getCPF(){
		return cpf;
	}
	
	public void setCPF(long num){
		cpf = num;
		return;
	}
	
	public float getAltura(){
		return altura;
	}
	
	public void setAltura(float num){
		altura = num;
		return;
	}
	
	public double getPeso(){
		return peso;
	}
	
	public void setPeso(double num){
		peso = num;
		return;
	}
	
	public String getEstadoCivil(){
		return estadoCivil;
	}
	
	public void setEstadoCivil(String str){
		estadoCivil = str;
		return;
	}
	
	public String getDataDeNascimento(){
		return dataDeNascimento;
	}
	
	public void setDataDeNascimento(String str){
		dataDeNascimento = str;
		return;
	}
	
	public PessoaFisica(String strNome, String strEndereco, String strEmail, int nIdade, long nCPF, float nAltura, double nPeso, String strEC, String strDdN){
		super(strNome,strEndereco,strEmail);
		idade = nIdade;
		cpf = nCPF;
		altura = nAltura;
		peso = nPeso;
		estadoCivil = strEC;
		dataDeNascimento = strDdN;
	}
	
	public PessoaFisica(){
		super(null,null,null);
		idade = 0;
		cpf = 0;
		altura = 0;
		peso = 0;
		estadoCivil = null;
		dataDeNascimento = null;
	}
	
}
