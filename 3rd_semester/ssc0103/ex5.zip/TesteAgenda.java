package poo.agenda;

public class TesteAgenda {

	public static void main(String[] args) {
		Agenda agenda = new Agenda();

	}

}
