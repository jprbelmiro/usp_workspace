package poo.pessoa;

public class PessoaJuridica extends Pessoa{
	
	private long cnpj;
	private long inscricaoEstadual;
	private String razaoSocial;
	
	@Override
	public String toString(){
		String str = "Nome: " + nome 
				+ "\n- endereco: " + endereco
				+ "\n- email: " + email
				+ "\n- cnpj: " + cnpj
				+ "\n- inscricao estadual: " + inscricaoEstadual
				+ "\n- razao social: " + razaoSocial + "\n";
		return str;
	}
	
	public long getCNPJ(){
		return cnpj;
	}
	
	public void setCNPJ(long num){
		cnpj = num;
		return;
	}
	
	public long getInscricaoEstatual(){
		return inscricaoEstadual;
	}
	
	public void setInscricaoEstadual(long num){
		inscricaoEstadual = num;
		return;
	}
	
	public String getRazaoSocial(){
		return razaoSocial;
	}
	
	public void setRazaoSocial(String str){
		razaoSocial = str;
		return;
	}
	
	public PessoaJuridica(String vNome, String vEndereco, String vEmail, long vCNPJ, long vIE, String vRS){
		super(vNome,vEndereco,vEmail);
		cnpj = vCNPJ;
		inscricaoEstadual = vIE;
		razaoSocial = vRS;
	}
	
	public PessoaJuridica(){
		super(null,null,null);
		cnpj = 0;
		inscricaoEstadual = 0;
		razaoSocial = null;
	}
	
}
