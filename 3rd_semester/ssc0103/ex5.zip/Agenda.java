package poo.agenda;


import java.util.ArrayList;
import poo.pessoa.Pessoa;
import poo.pessoa.PessoaFisica;
import poo.pessoa.PessoaJuridica;

public class Agenda {
	
	int nContatos = 0;
	ArrayList<Pessoa> contato = null;
	
	@Override
	public String toString(){
		String str = null;
		for(int i = 0 ; i < nContatos ; i++){
			if(i == 0)
				str = (contato.toArray())[i].toString();
		}
		return str;
	}
	
	public void bubbleSort(int start, int end){
		Pessoa aux;
        boolean troca = true;
      
        while (troca){
        	troca = false;
            for (int i = start; i < end - 1; i++) {
            	if ((contato.toArray())[i] instanceof PessoaFisica) {
                	PessoaFisica cf = (PessoaFisica) (contato.toArray())[i];
                	PessoaFisica cff = (PessoaFisica) (contato.toArray())[i+1];
                	if(cf.getCPF() > cff.getCPF()){
	                    aux = (contato.toArray())[i];
	                    (contato.toArray())[i] = (contato.toArray())[i + 1];
	                    (contato.toArray())[i + 1] = aux;
	                    troca = true;
                	}
                }
            	else if ((contato.toArray())[i] instanceof PessoaJuridica) {
                	PessoaJuridica cj = (PessoaJuridica) (contato.toArray())[i];
                	PessoaJuridica cjj = (PessoaJuridica) (contato.toArray())[i+1];
                	if(cj.getCNPJ() > cjj.getCNPJ()){
	                    aux = (contato.toArray())[i];
	                    (contato.toArray())[i] = (contato.toArray())[i + 1];
	                    (contato.toArray())[i + 1] = aux;
	                    troca = true;
                	}
                }
            }
        }
        
        return;
	}
	
	public void bubbleSort(){
		Pessoa aux;
        boolean troca = true;
      
        while (troca){
        	troca = false;
            for (int i = 0; i < nContatos - 1; i++) {
                if ((contato.toArray())[i] instanceof PessoaJuridica && (contato.toArray())[i+1] instanceof PessoaFisica) {
                    aux = (contato.toArray())[i];
                    (contato.toArray())[i] = (contato.toArray())[i + 1];
                    (contato.toArray())[i + 1] = aux;
                    troca = true;
                }
            }
        }
        
        return;
	}
	
	public void ordena(Pessoa[] contato){
		//1.Ordenando por pessoa fisica/juridica...
		bubbleSort();
		
		//2.Procurando o indice da ultima pessoa fisica
		//e o indice da primeira pessoa juridica da agenda...
		int i;
		for( i = 0 ; contato[i] instanceof PessoaFisica; i++);
		int ultimaPF = i-1;
		int primeiraPJ = i;
		
		//3. Ordenando as pessoas fisicas por cpf e as juridicas
		//por cnpj...
		bubbleSort(0,ultimaPF);
		bubbleSort(primeiraPJ,nContatos-1);
		
		//4. Ordenacao concluida...
		return;
    }
	
	public void add(Pessoa p){
		nContatos += 1;
		
	}
	
	public Agenda(int n, Pessoa[] preset){
		nContatos = n;
		contato = new ArrayList<Pessoa>();
		for(int i = 0 ; i < n ; i++)
			(contato.toArray())[i] = preset[i];
	}	
	
	public Agenda(){
		nContatos = 0;
		contato = null;
	}
	
}
