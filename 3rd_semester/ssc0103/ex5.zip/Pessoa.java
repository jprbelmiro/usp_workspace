package poo.pessoa;

public class Pessoa {

	protected String nome;
	protected String endereco;
	protected String email;
	
	public String getNome(){
		return nome;
	}

	public void setNome(String str){
		nome = str;
		return;
	}
	
	public String getEndereco(){
		return endereco;
	}

	public void setEndereco(String str){
		endereco = str;
		return;
	}
	
	public String getEmail(){
		return email;
	}

	public void setEmail(String str){
		email = str;
		return;
	}
	
	
	public Pessoa(String strNome, String strEndereco, String strEmail){
		nome = strNome;
		endereco = strEndereco;
		email = strEmail;
	}
	
	public Pessoa(){
		nome = null;
		endereco = null;
		email = null;
	}
	
}
