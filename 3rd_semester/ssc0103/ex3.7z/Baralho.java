package poo;

public class Baralho extends Carta{

	int ncartas;
	Carta[] cartas;
	
	@Override
	public String toString(){
		String str = null;
		
		for(int i = 0; i < 13 ; i++){
			for(int j = 0 ; j < 4 ; j++){
				if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else if(cartas[i*4+j].getValor() == A)
					System.out.printf("A");
				else System.out.printf("X");
				
				if(cartas[i*4+j].getNaipe() == PAUS)
					System.out.printf("1");
				else if(cartas[i*4+j].getNaipe() == COPAS)
					System.out.printf("2");
				else if(cartas[i*4+j].getNaipe() == ESPADAS)
					System.out.printf("3");
				else if(cartas[i*4+j].getNaipe() == OURO)
					System.out.printf("4");
				else System.out.printf("5");
					
			}System.out.printf("6");
		}
			
		
		return str;
	}
	
	public Baralho(){
		ncartas = 52;
		cartas = new Carta[52];
		
		int counter = 0;
		for(int valor = 0 ; valor < 13 ; valor++)
			for(int naipe = 0 ; naipe < 4; naipe++)
				cartas[counter++] = new Carta(valor,naipe);

	}
	
}
