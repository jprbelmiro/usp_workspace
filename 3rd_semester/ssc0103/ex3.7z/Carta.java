package poo;

public class Carta {
	
	private static final int INVALID = -1;
	
	protected static final int PAUS = 3;
	protected static final int COPAS = 2;
	protected static final int ESPADAS = 1;
	protected static final int OURO = 0;

	protected int A = 12;
	protected int K = 11;
	protected int J = 10;
	protected int Q = 9;
	protected int DEZ = 8;
	protected int NOVE = 7;
	protected int OITO = 6;
	protected int SETE = 5;
	protected int SEIS = 4;
	protected int CINCO = 3;
	protected int QUATRO = 2;
	protected int TRES = 1;
	protected int DOIS = 0;
	
	private int valor;
	private int naipe;
	
	public int getNaipe(){
		return naipe;
	}
	
	protected void setNaipe(int n){
		naipe = n;
		return;
	}
	
	public int getValor(){
		return valor;
	}
	
	protected void setValor(int v){
		valor = v;
		return;
	}
	
	public Carta(String str){
		if(str.matches("^\\s*[a-zA-Z2-10]{1,2}[\\s,;]+[a-zA-Z]{4,7}\\s*$")){
			if(str.matches("^\\s*[Aa]{1}")) valor = A;
			else if(str.matches("^\\s*[Kk]{1}")) valor = K;
			else if(str.matches("^\\s*[Jj]{1}")) valor = J;
			else if(str.matches("^\\s*[Qq]{1}")) valor = Q;
			else if(str.matches("^\\s*[10]{1}")) valor = DEZ;
			else if(str.matches("^\\s*[9]{1}")) valor = NOVE;
			else if(str.matches("^\\s*[8]{1}")) valor = OITO;
			else if(str.matches("^\\s*[7]{1}")) valor = SETE;
			else if(str.matches("^\\s*[6]{1}")) valor = SEIS;
			else if(str.matches("^\\s*[5]{1}")) valor = CINCO;
			else if(str.matches("^\\s*[4]{1}")) valor = QUATRO;
			else if(str.matches("^\\s*[3]{1}")) valor = TRES;
			else if(str.matches("^\\s*[2]{1}")) valor = DOIS;
			else valor = INVALID;
			
			
			if(str.matches("[\\s,;]+[Pp][Aa][Uu][Ss]\\s*$")) naipe = PAUS;
			else if(str.matches("[\\s,;]+[Cc][Oo][Pp][Aa][Ss]\\s*$")) naipe = COPAS;
			else if(str.matches("[\\s,;]+[Es][Ss][Pp][Aa][Dd][Aa][Ss]\\s*$")) naipe = ESPADAS;
			else if(str.matches("[\\s,;]+[Oo][Uu][Rr][Oo]\\s*$")) naipe = OURO;
			else naipe = INVALID;
		}
		else if(str.matches("^\\s*[a-zA-Z]{4,7}[\\s,;]+[a-zA-Z2-10]{1,2}$"));
	}
	
	public Carta(int v, int n){
		valor = v;
		naipe = n;
	}
	
	public Carta(){
		Random r = new Random();
		valor = r.getIntRand(12);
		naipe = r.getIntRand(3);
	}
	
}
